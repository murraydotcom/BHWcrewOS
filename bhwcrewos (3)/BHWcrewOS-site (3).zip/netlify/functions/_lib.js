// netlify/functions/_lib.js — shared helpers for BHWcrewOS
const crypto = require("crypto");

const NOTION = "https://api.notion.com/v1";

// Notion database IDs (created 7/4/2026 under "BHW Operations Hub — Data Layer")
const DB = {
  staff: "23241ce30cba4b01adb858afbe95d11f",
  patients: "f9a0291f34aa4d559fbc920c79d219b4",
  rooms: "1686d78712c7437dbb09fb01281e32e2",
  availability: "f5594085117d442e9f90f5ea0f31e509",
  schedule: "318c41c02c4248f99fce30b35172f785",
  referrals: "38d1e95e77944d4c9e9fd9a656bc3f70",
  handoffs: "cef65566ce924b56a01961eb66b15161",
  minutes: "818f2fa362aa40fc9032d1388a047a3f",
  meetings: "f498ac069a0447e78d3aa0763bf81827",
  porterhouse: "d5d6639fe9464c56b48b42d2a8ed9fac",
  resources: "96dd6b0fd4f9423e849df6e540caed94",
};

const DIVISIONS = ["Primary Care", "CharmEd Minds", "Mind & Mood Recovery", "The Porter House", "Chronic Care", "Flow"];

// ---------- Notion ----------
function headers() {
  return {
    Authorization: `Bearer ${process.env.NOTION_TOKEN}`,
    "Notion-Version": "2022-06-28",
    "Content-Type": "application/json",
  };
}

async function queryDb(dbId, filter, sorts) {
  const results = [];
  let cursor;
  do {
    const res = await fetch(`${NOTION}/databases/${dbId}/query`, {
      method: "POST",
      headers: headers(),
      body: JSON.stringify({ start_cursor: cursor, ...(filter ? { filter } : {}), ...(sorts ? { sorts } : {}) }),
    });
    if (!res.ok) throw new Error(`Notion ${res.status} querying ${dbId}: ${await res.text()}`);
    const data = await res.json();
    results.push(...data.results);
    cursor = data.has_more ? data.next_cursor : undefined;
  } while (cursor);
  return results;
}

async function createPage(dbId, properties) {
  const res = await fetch(`${NOTION}/pages`, {
    method: "POST",
    headers: headers(),
    body: JSON.stringify({ parent: { database_id: dbId }, properties }),
  });
  if (!res.ok) throw new Error(`Notion create ${res.status}: ${await res.text()}`);
  return res.json();
}

async function updatePage(pageId, properties) {
  const res = await fetch(`${NOTION}/pages/${pageId}`, {
    method: "PATCH",
    headers: headers(),
    body: JSON.stringify({ properties }),
  });
  if (!res.ok) throw new Error(`Notion update ${res.status}: ${await res.text()}`);
  return res.json();
}

// ---------- Property readers ----------
const P = {
  title: (p) => p?.title?.map((t) => t.plain_text).join("") || "",
  text: (p) => p?.rich_text?.map((t) => t.plain_text).join("") || "",
  sel: (p) => p?.select?.name || "",
  multi: (p) => (p?.multi_select || []).map((o) => o.name),
  check: (p) => !!p?.checkbox,
  num: (p) => (typeof p?.number === "number" ? p.number : null),
  date: (p) => p?.date?.start || "",
  rel: (p) => (p?.relation || []).map((r) => r.id),
  uid: (p) => (p?.unique_id ? `${p.unique_id.prefix}-${p.unique_id.number}` : ""),
};

// ---------- Property writers ----------
const W = {
  title: (v) => ({ title: [{ text: { content: String(v).slice(0, 200) } }] }),
  text: (v) => ({ rich_text: v ? [{ text: { content: String(v).slice(0, 1900) } }] : [] }),
  sel: (v) => (v ? { select: { name: v } } : { select: null }),
  date: (v) => (v ? { date: { start: v } } : { date: null }),
  num: (v) => ({ number: v === null || v === undefined || v === "" ? null : Number(v) }),
  rel: (ids) => ({ relation: (ids || []).filter(Boolean).map((id) => ({ id })) }),
  check: (v) => ({ checkbox: !!v }),
};

// ---------- Sessions (HMAC-signed, no server-side store needed) ----------
function sign(payload) {
  const secret = process.env.SESSION_SECRET;
  if (!secret) throw new Error("SESSION_SECRET not set");
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const sig = crypto.createHmac("sha256", secret).update(body).digest("base64url");
  return `${body}.${sig}`;
}

function verify(token) {
  try {
    const secret = process.env.SESSION_SECRET;
    const [body, sig] = String(token || "").split(".");
    const expected = crypto.createHmac("sha256", secret).update(body).digest("base64url");
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
    const payload = JSON.parse(Buffer.from(body, "base64url").toString());
    if (!payload.exp || Date.now() > payload.exp) return null;
    return payload; // { staffId, name, divisions, access, landing, canSchedule, exp }
  } catch {
    return null;
  }
}

function getSession(event) {
  const auth = event.headers?.authorization || event.headers?.Authorization || "";
  return verify(auth.replace(/^Bearer\s+/i, ""));
}

// Server-side division wall: which divisions can this session see?
function visibleDivisions(session) {
  if (session.access === "Admin" || (session.divisions || []).includes("All")) return DIVISIONS;
  return session.divisions || [];
}

function json(statusCode, body) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
    body: JSON.stringify(body),
  };
}

module.exports = { DB, DIVISIONS, queryDb, createPage, updatePage, P, W, sign, verify, getSession, visibleDivisions, json };
